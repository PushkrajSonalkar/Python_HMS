# Hospital Management System

# Import

from sys import exit
from os import system, name, path, mkdir
from datetime import date

import random
import string


class Hospital(object):
    # Initial Function
    def __init__(self, user_name, password):
        self.user_name = user_name
        self.password = password

    # Login Function
    def login(self):
        # This is the login function of system.
        def clear():
            # for Windows clear screen. 'nt' is used bye OS (import) for Windows OS.
            if name == 'nt':
                _ = system('cls')

        if self.user_name == 'ADMIN' and self.password == 'admin123':            # Checking login
            # Successful
            self.reception()
        else:
            # Failed
            print "provide valid user name and password"
            clear()

    # Receptionist Function
    def reception(self):
        """This Function is used for by the Receptionist to handle all the things
        also it contains the main menu"""

        reception_choice = 0
        while reception_choice != 4:
            # The Main Menu Enter Choice List
            reception_choice = int(raw_input("\nMain Menu Enter Choice\n"
                                             "1.Take Appointment of OPD 2.Take OT Registration "
                                             "3.Emergency Case 4.Exit\n"))
            if reception_choice == 1:
                self.take_appointment()
            elif reception_choice == 2:
                self.take_ot_registration()
            elif reception_choice == 3:
                self.emergency_case()
            elif reception_choice == 4:
                break
            else:
                print "Please provide valid choice"
        exit(1)

    def take_appointment(self):
        # This is a Static Function is used for Take Appointment for OPD

        patient_details = {}

        def new_appointment():
            # This Function is used for Take New Appointment for OPD (UNDER take_appointment FUNCTION)

            def ran_gen(size, chars=string.ascii_uppercase + string.digits):
                # This Function create random id for patients (UNDER new_appointment FUNCTION)
                return ''.join(random.choice(chars) for x in range(size))

            def create_patient_directory(temp_id):
                # This function creates particular patient directories (UNDER new_appointment FUNCTION)
                dir_name = "patient_details\\" + temp_id

                # Create target Directory if don't exist
                if not path.exists(dir_name):
                    mkdir(dir_name)
                    print("Directory ", dir_name, " Created ")
                    return dir_name
                else:
                    print("Directory ", dir_name, " already exists")

            patient_id = ran_gen(8, 'HOSPITAL19')       # function call for random patient id
            directory_name = create_patient_directory(patient_id)   # Creating patient separate directory

            details = {
                # 'name': 'name', 'treatment': 'sac', 'age': '22', 'last_visited_date': 'date',
                # 'doctor_name': 'name'
            }

            patient_name = patient_id + '_name'
            patient_treatment = patient_id + '_treatment'
            patient_age = patient_id + '_age'
            doctor_allocated = patient_id + '_allocated_doctor'
            patient_id_last_visit_date = patient_id + '_last_visit_date'
            details[patient_name] = raw_input("Enter Patient Name\n")
            details[patient_treatment] = raw_input("Enter Treatment of Patient\n")
            details[patient_age] = float(raw_input("Enter Age\n"))
            details[patient_id_last_visit_date] = date.today()   # date.today() for current date
            details[doctor_allocated] = raw_input("Enter doctor allocated to patient\n")
            patient_details[patient_id] = details
            print "%s is get new appointment" % patient_id

            # for creating particular day records file
            file_path = directory_name + "\\" + str(details[patient_id_last_visit_date])

            # print file_path
            file_pointer = open(file_path, 'a')
            file_pointer.write(str(patient_details))

        def revisited_appointment():
            # This Function is used for revisited Appointment for OPD (UNDER take_appointment FUNCTION)
            pass

        def advanced_booking():
            """This Function is used for Advanced Booking of Appointment
             for OPD (UNDER take_appointment FUNCTION)"""
            pass

        def get_all_patient():
            print patient_details

        take_appointment_choice = 0
        while take_appointment_choice != 4:
            # The Appointment Menu Enter Choice List
            take_appointment_choice = int(
                raw_input("\nAppointment Menu Enter Choice\n1.New Appointment 2.Revisited "
                          "3.Advanced Booking of Appointment 4.Get all Patient Details "
                          "5. Search 6.Go back to Main menu\n"))

            # Checking which choice is made upon that function will called further
            if take_appointment_choice == 1:
                new_appointment()
            elif take_appointment_choice == 2:
                revisited_appointment()
            elif take_appointment_choice == 3:
                advanced_booking()
            elif take_appointment_choice == 4:
                get_all_patient()
            elif take_appointment_choice == 5:
                pass
            elif take_appointment_choice == 6:
                break
            else:
                print "Please provide valid choice"


# Main i.e. DRIVER CODE
login_choice = 1
while login_choice == 1:
    login = " Login Here "
    text_login_center = login.center(50, '-')
    print text_login_center
    user = raw_input("Enter User Name:\n")
    psw = raw_input("Enter password:\n")
    a = Hospital(user, psw)
    a.login()
    login_choice = int(raw_input("\n0. You want to exit...? 1. Continue...!\n"))

