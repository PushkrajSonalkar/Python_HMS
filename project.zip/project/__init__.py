# Hospital Management System


class Hospital(object):
    def __enter__(self):
        pass


class Appointment(object):
    def __enter__(self):
        pass
