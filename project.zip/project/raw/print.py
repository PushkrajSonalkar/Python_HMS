def print_total(self):
    """
    print_total function will calculate the cart total and display the total
    """
    price_sum = 0
    for price in self.cart_price:
        price_sum = price_sum + price
    rupee_symbol = u"\u20B9"
    print "CART TOTAL = ", rupee_symbol, price_sum
    return price_sum

def print_receipt(self, name):
    """
    print_receipt function is used to print the receipt for the consumer
    """
    print "\n\t\t\t\tReceipt"
    print "-" * 40, "\nConsumer Name:", name.upper(), "\n", "-" * 40
    for i in range(0, len(self.cart_items)):
        for j in range(0, len(self.cart_quantity)):
            for k in range(0, len(self.cart_price)):
                RECEIPT_ELEMENTS.append(self.cart_items[i])
                RECEIPT_ELEMENTS.append(self.cart_quantity[j])
                RECEIPT_ELEMENTS.append(self.cart_price[k])
                k += 1
                j += 1
                i += 1
            break
        break
    display_table = tt.Texttable()
    headings = ['Item Name', 'Quantity', 'Price']
    display_table.header(headings)
    for row in zip(self.cart_items, self.cart_quantity, self.cart_price):
        display_table.add_row(row)
    view_table = display_table.draw()
    print (view_table)
    self.print_total()
    print "-" * 40
    email_address = raw_input("Enter your email address to send receipt >")
    send_receipt(email_address, name)
    exit(0)
