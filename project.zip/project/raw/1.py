            def create_patient_directory(temp_id):
                # This function creates particular patient directories (UNDER new_appointment FUNCTION)
                dir_name = "patient_details\\" + temp_id

                # Create target Directory if don't exist
                if not path.exists(dir_name):
                    mkdir(dir_name)
                    print("Directory ", dir_name, " Created ")
                    return dir_name
                else:
                    print("Directory ", dir_name, " already exists")

 directory_name = create_patient_directory(patient_id)   # Creating patient separate directory


            # for creating particular day records file
            file_path = directory_name + "\\" + str(details[patient_id_last_visit_date])

            # print file_path
            file_pointer = open(file_path, 'a')
            file_pointer.write(str(patient_details))
