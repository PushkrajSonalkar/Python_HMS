# Tuple Built-in Functions

# Tuple
Tuple1 = (1, 4, 5, 2, 3)
print Tuple1

# count()
print Tuple1.count(1)

# index()
print Tuple1.index(5)

# Length of Tuple
print len(Tuple1)

# Maximum Element
print max(Tuple1)

# Min Element
print min(Tuple1)

# Sum of all Elements
print sum(Tuple1)

# Sort Tuple
print sorted(Tuple1)

# all()
print all(Tuple1)

# any()
print any(Tuple1)

# Enumerate
print enumerate(Tuple1)

List1 = [1, 2, 3, 'a']
print tuple(List1)
