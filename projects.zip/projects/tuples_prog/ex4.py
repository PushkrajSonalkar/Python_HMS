# Deleting a Tuple

Tuple1 = (0, 1, 2, 3, 4)

del Tuple1

print(Tuple1)
