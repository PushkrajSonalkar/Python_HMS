# Packing and Unpacking a Tuple in Python

# this lines PACKS values
# into variable Tuple1
Tuple1 = ('Arnav', 25, 'Sonalkar')

# this lines UNPACKS values
# of variable Tuple1
(first_name, age, last_name) = Tuple1

# Printing value of first_name, age & last_name
print "First Name: %s\nLast Name: %s\nAge: %d" %(first_name, last_name, age)
