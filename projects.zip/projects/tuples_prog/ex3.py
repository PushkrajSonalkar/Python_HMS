# Slicing of a Tuple

# Slicing of a Tuple
# with Numbers

Tuple1 = tuple('ARNAVRAVINDRASONALKAR')

# Print Tuple
print Tuple1

# Removing First element
print "\nRemoval of 1st Element:"
print Tuple1[1:]

# Reversing the Tuple
print "\nTuple after sequence of Element is reversed: "
print Tuple1[::-1]

# Printing elements of a Range
print("\nPrinting elements between Range 5-12: ")
print Tuple1[5:13]
