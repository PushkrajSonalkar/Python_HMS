# Tuple operations i.e. Concatenation

Tuple1 = (0, 1, 2, 3)
Tuple2 = ('Mr.', 'Arnav', 'Ravindra', 'Sonalkar')

Tuple3 = Tuple1 + Tuple2

# Printing 1st Tuple
print Tuple1

# Printing 2nd Tuple
print Tuple2

# Printing Concatenated Tuple
print Tuple3


