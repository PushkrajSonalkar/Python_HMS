# String Reverse

s = raw_input("Enter a String\n")

print s[::-1]