# Hospital Management System

# Import

from os import system, name, path, mkdir
from datetime import date
import texttable as tt


class Hospital(object):
    users_of_system = {}

    # Initial Function

    def __init__(self, user_name, password):
        self.user_name = user_name
        self.password = password

    # Clear Screen Function
    def clear(self):
        # for Windows clear screen. 'nt' is used bye OS (import) for Windows OS.
        if name == 'nt':
            _ = system('cls')

    # Login Function
    def login(self):
        # This is the login function of system.
        user_backup = {}

        file_path = "user_details" + "\\" + "users_of_system.txt"
        if path.exists(file_path):
            file_pointer = open(file_path, 'r')
            data = file_pointer.read()
            user_backup = eval(data)
            # print file_pointer
        else:
            pass
            # patient_backup = {}

        temp_user = self.user_name
        temp_password = self.password
        self.users_of_system.update(user_backup)
        # print temp_user
        counter = 0
        for p_id, p_info in self.users_of_system.items():
            # print "\nPatient ID:", p_id
            if self.users_of_system.get(p_id).get("user_password") == temp_password \
                and self.users_of_system.get(p_id).get("user_name") == temp_user \
                    and self.users_of_system.get(p_id).get("user_role") == "Receptionist":
                self.reception()
            elif self.users_of_system.get(p_id).get("user_password") == temp_password \
                and self.users_of_system.get(p_id).get("user_name") == temp_user \
                    and self.users_of_system.get(p_id).get("user_role") == "Doctor":
                self.doctor()
            elif self.users_of_system.get(p_id).get("user_password") == temp_password \
                and self.users_of_system.get(p_id).get("user_name") == temp_user \
                    and self.users_of_system.get(p_id).get("user_role") == "Billing Department":
                self.billing()
            else:
                counter += 1

        if counter == len(self.users_of_system):
            # Failed
            print "provide valid user name and password"
            self.clear()

    # Registration
    def registration(self):
        user_name = 'user_name'
        user_password = 'user_password'
        user_role = 'user_role'
        user_name_value = self.user_name
        temp_user_details = {}
        details = {}
        register_choice = int(raw_input("\nEnter The Registration Choice\n1. Receptionist  2. Doctor"
                                        " 3. Billing Department\n"))

        details[user_name] = user_name_value
        details[user_password] = self.password
        user_id = self.generate_id(self.users_of_system, "user_details", "users_of_system")
        if register_choice == 1:
            details[user_role] = "Receptionist"
        elif register_choice == 2:
            details[user_role] = "Doctor"
        elif register_choice == 3:
            details[user_role] = "Billing Department"
        else:
            print "Enter Valid Choice"
        temp_user_details[user_id] = details
        self.users_of_system.update(temp_user_details)
        self.back_up_data(self.users_of_system, "user_details", "users_of_system")
        opd_register = " User Successfully Registered "
        text_opd_register = opd_register.center(50, '-')
        print text_opd_register
        return self.users_of_system

    # Receptionist Function
    def reception(self):
        """This Function is used for by the Receptionist to handle all the things
        also it contains the main menu"""

        print "Welcome Receptionist", self.user_name
        reception_choice = 0
        while reception_choice != 4:
            # The Main Menu Enter Choice List
            reception_choice = int(raw_input("\nMain Menu Enter Choice\n"
                                             "1.Take Appointment of OPD 2.Take OT Registration "
                                             "3.Emergency Case 4.Exit\n"))
            if reception_choice == 1:
                self.take_appointment()
            elif reception_choice == 2:
                self.take_ot_registration()
            elif reception_choice == 3:
                self.emergency_case()
            elif reception_choice == 4:
                break
            else:
                print "Please provide valid choice"

    # Doctor Function
    def doctor(self):
        # This Function is used for by the Doctor to handle all the things

        print "\nWelcome Doctor", self.user_name

        patient_details = patient_details_of_ot = emergency_case_patient_details = {}
        opd_date = emergency_date = str(date.today())
        # doctor_work_choice = 0
        doctor_work_choice = int(raw_input("Doctor Main Menu Enter Choice\n1. Get Information about Patient "
                                           "2. Give Medicines (i.e. After Treatment) 3. Exit:\n"))
        while doctor_work_choice != 3:
            if doctor_work_choice == 1:
                self.get_details_of_patient(patient_details, patient_details_of_ot, emergency_case_patient_details,
                                            opd_date, emergency_date)
                doctor_work_choice = int(raw_input("Doctor Main Menu Enter Choice\n1. Get Information about Patient "
                                                   "2. Give Medicines (i.e. After Treatment) "
                                                   "3. Back To Previous Menu:\n"))
            elif doctor_work_choice == 2:
                self.set_medicine_of_patient(patient_details, patient_details_of_ot, emergency_case_patient_details,
                                             opd_date, emergency_date)
                doctor_work_choice = int(raw_input("Doctor Main Menu Enter Choice\n1. Get Information about Patient "
                                                   "2. Give Medicines (i.e. After Treatment) "
                                                   "3. Back To Previous Menu:\n"))
            elif doctor_work_choice == 3:
                break
            else:
                print "Please Provide Valid Choice Doctor" + self.user_name

    # Billing Department
    def billing(self):
        # This Function is used for by the Billing Department to handle all the things related to billing
        print "\nWelcome Billing Operator", self.user_name

        patient_details_of_ot = emergency_case_patient_details = {}
        emergency_date = str(date.today())
        doctor_work_choice = 0

        while doctor_work_choice != 3:
            doctor_work_choice = int(raw_input("Billing Department Main Menu Enter Choice\n1. Billing of OT patient "
                                               "2. Billing of Emergency Case Patient 3. Exit\n"))
            if doctor_work_choice == 1:
                self.get_billing(patient_details_of_ot, "ot_patient_details", emergency_date)
            elif doctor_work_choice == 2:

                self.get_billing(emergency_case_patient_details, "emergency_case_patient_details", emergency_date)
            elif doctor_work_choice == 3:
                break
            else:
                print "Please Provide Valid Choice Doctor" + self.user_name

    # This Function is used to set medicines
    def set_medicine_of_patient(self, patient_details, patient_details_of_ot, emergency_case_patient_details,
                                opd_date, emergency_date):
        doctor_choice = 0
        while doctor_choice != 4:
            doctor_choice = int(raw_input("\nDoctor Sub Menu Enter Choice\n "
                                          "1. OPD Patient Treatment  2. OT Patient Treatment "
                                          "3. Emergency Case Patient Treatment 4. Back To Previous Menu\n"))
            if doctor_choice == 1:
                counter = self.get_patient_details(patient_details, "opd_patient_details", opd_date)
                if not counter == len(patient_details):
                    self.set_medicine_of_patient_for_doctor(patient_details, "opd_patient_details", opd_date)
                else:
                    print "Doctor " + self.user_name + "\n You don't have any OPD cases for treatment on " + opd_date
            elif doctor_choice == 2:
                ot_date = raw_input("Enter the date in format \'YYYY-MM-DD\':\n")
                counter = self.get_patient_details(patient_details_of_ot, "ot_patient_details", ot_date)
                if not counter == len(patient_details_of_ot):
                    self.set_medicine_of_patient_for_doctor(patient_details_of_ot, "ot_patient_details", ot_date)
                else:
                    print "Doctor " + self.user_name + "\n You don't have any OT cases for treatment on " + ot_date
            elif doctor_choice == 3:
                counter = self.get_patient_details(emergency_case_patient_details,
                                                   "emergency_case_patient_details", emergency_date)
                if not counter == len(patient_details_of_ot):
                    self.set_medicine_of_patient_for_doctor(emergency_case_patient_details,
                                                            "emergency_case_patient_details", emergency_date)
                else:
                    print "Doctor " + self.user_name + "\n You don't have any Emergency cases for treatment on " \
                          + emergency_date
            elif doctor_choice == 4:
                break
            else:
                print "Please provide valid choice"

    # This Function is used to get Patients Details
    def get_details_of_patient(self, patient_details, patient_details_of_ot, emergency_case_patient_details,
                               opd_date, emergency_date):
        doctor_choice = 0
        while doctor_choice != 4:
            # The Main Menu Enter Choice List
            doctor_choice = int(raw_input("\nDoctor Sub Menu Enter Choice\n "
                                          "1.Get OPD Patient Details of Today 2.Get OT Patient Details "
                                          "3.Get Emergency Case Patient Details of Today 4. Back To Previous Menu\n"))
            if doctor_choice == 1:
                counter = self.get_patient_details(patient_details, "opd_patient_details", opd_date)
                if counter == len(emergency_case_patient_details):
                    print "Doctor " + self.user_name + "\n You don't have any OPD cases on " + opd_date
            elif doctor_choice == 2:
                ot_date = raw_input("Enter the date in format \'YYYY-MM-DD\':\n")
                counter = self.get_patient_details(patient_details_of_ot, "ot_patient_details", ot_date)
                if counter == len(emergency_case_patient_details):
                    print "Doctor " + self.user_name + "\n You don't have any OT cases on " + ot_date
            elif doctor_choice == 3:
                counter = self.get_patient_details(emergency_case_patient_details,
                                                   "emergency_case_patient_details", emergency_date)
                if counter == len(emergency_case_patient_details):
                    print "Doctor " + self.user_name + "\n You don't have any Emergency cases on " + emergency_date
            elif doctor_choice == 4:
                break
            else:
                print "Please provide valid choice"

    # Common Function Area Start

    def get_billing(self, dict_name, file_name, corresponding_date):
        billing_details = {}
        temp_bill = {}
        temp_details = {}
        admitted_date = raw_input("Enter the Date of Bill in \'YYYY-MM-DD\' Format:\n")
        patient_backup = self.get_hospitalized_patient(dict_name, file_name, admitted_date)

        billing_status = self.get_hospitalized_patient_for_billing(patient_backup, file_name, corresponding_date)
        if billing_status == True:
            self.generate_bill(patient_backup, temp_details, temp_bill, billing_details, corresponding_date, file_name,
                               admitted_date)
        else:
            print "No Details Available"

    def generate_bill(self, patient_backup, temp_details, temp_bill, billing_details, corresponding_date, file_name,
                      admitted_date):
        billing_id = self.generate_id(patient_backup, "patient_billing_details", corresponding_date)
        billing_date = 'billing_date'
        service_details = 'service_details'
        price = 'price'
        list_of_services = {}
        p_id = int(raw_input("Enter Patient Id:\n"))
        if patient_backup.get(p_id). has_key('medicines'):
            for k_id, p_info in patient_backup.items():
                for key in p_info:
                    temp_bill[key] = p_info[key]
            billing_choice = 1
            while billing_choice == 1:
                service_id = self.generate_id(temp_details, "raw", corresponding_date)
                billing_date_of_patient = raw_input("Enter the Date of Bill in \'YYYY-MM-DD\' Format:\n")
                list_of_services[billing_date] = billing_date_of_patient
                list_of_services[service_details] = raw_input("Enter the service Details:\n")
                list_of_services[price] = float(raw_input("Enter the Price:\n"))
                temp_details[service_id] = list_of_services
                temp_details.update(temp_details)
                self.back_up_data(temp_details, "raw", corresponding_date)
                billing_choice = int(raw_input("0. Do you want generate bill...? "
                                               "1. Continue Adding Billing Details\n"))
            temp_bill['billing_content'] = temp_details
            billing_details[billing_id] = temp_bill
            self.back_up_data(billing_details, "patient_billing_details", corresponding_date)
            self.back_up_data(billing_details, file_name, admitted_date)
            bill_generation = " Patient Bill is Successfully Generated"
            text_bill_generation = bill_generation.center(50, '-')
            print text_bill_generation
            self.print_billing(billing_details, billing_id, temp_details)

    def get_hospitalized_patient_for_billing(self, dict_name, file_name, corresponding_date):
        file_path = file_name + "\\" + corresponding_date + ".txt"
        if path.exists(file_path):
            file_pointer = open(file_path, 'r')
            data = file_pointer.read()
            patient_backup = eval(data)
            # print file_pointer
        else:
            patient_backup = {}
        temp_user = self.user_name
        counter = True
        dict_name.update(patient_backup)
        for p_id, p_info in dict_name.items():
            # print "\nPatient ID:", p_id

            if not dict_name.get(p_id, {}). has_key('billing_date'):
                print "\nPatient ID:", p_id
                for key in p_info:
                    print key + ':', p_info[key]
            else:
                counter = False
        return counter

    # Print Bill
    def print_billing(self, billing_details, p_id, temp_bill):
        bill_generation = " BILLING DETAILS"
        text_bill_generation = bill_generation.center(50, '-')
        print text_bill_generation
        print "Patient Name: ", billing_details[p_id]['name'],
        print "Patient Treatment: ", billing_details[p_id]['treatment']
        print "Patient Age: ", billing_details[p_id]['age'],
        print "Doctor Allocated: ", billing_details[p_id]['allocated_doctor']
        print "Admitted Date: ", billing_details[p_id]['date']

        service = billing_date = price = []
        total_price = 0

        table = tt.Texttable()
        for i, info in temp_bill.items():

            service.append(temp_bill[i]['service_details'])
            billing_date.append(temp_bill[i]['billing_date'])
            price.append(temp_bill[i]['price'])

        headings = ['Date', 'Service', 'Price']
        table.header(headings)
        print price
        # total_price = sum(price)
        for row in zip(billing_date, service, price):
            table.add_row(row)
        view_table = table.draw()
        print (view_table)
        print "Total Price is:", u"\u20B9", total_price
        del service[:]
        del price[:]
        del billing_date[:]

    # Get Hospitalized Patient
    def get_hospitalized_patient(self, dict_name, file_name, corresponding_date):
        # Display Patient
        file_path = file_name + "\\" + corresponding_date + ".txt"
        if path.exists(file_path):
            file_pointer = open(file_path, 'r')
            data = file_pointer.read()
            patient_backup = eval(data)
            # print file_pointer

        else:
            patient_backup = {}
        for p_id, p_info in dict_name.items():
            # print "\nPatient ID:", p_id

            if not dict_name.get(p_id). has_key('medicines'):
                pass
            else:
                print "\nPatient ID:", p_id
                for key in p_info:
                    print key + ':', p_info[key]
        return patient_backup

    # This Function used for getting details of patient for Receptionist
    def get_details(self, dict_name, file_path, corresponding_date):
        file_path = file_path + "\\" + corresponding_date + ".txt"
        if path.exists(file_path):
            file_pointer = open(file_path, 'r')
            data = file_pointer.read()
            patient_backup = eval(data)
            # print file_pointer
        else:
            patient_backup = {}
        temp_user = self.user_name
        counter = 0
        dict_name.update(patient_backup)
        for p_id, p_info in dict_name.items():
            # print "\nPatient ID:", p_id

            if not dict_name.get(p_id, {}). has_key('medicines'):
                print "\nPatient ID:", p_id
                for key in p_info:
                    print key + ':', p_info[key]
            else:
                counter = p_id
        return counter

    # This Function is used to set medicines of Particular Patient
    def set_medicine_of_patient_for_doctor(self, dict_name, file_path, corresponding_date):
        medicine = {}
        file_name = file_path
        file_path = file_name + "\\" + corresponding_date + ".txt"
        if path.exists(file_path):
            file_pointer = open(file_path, 'r')
            data = file_pointer.read()
            patient_backup = eval(data)
            # print file_pointer
        else:
            patient_backup = {}
        temp_user = self.user_name
        dict_name.update(patient_backup)
        p_id = int(raw_input("Enter Patient Id which you want to provide Medicines:\n"))

        if dict_name.get(p_id).get("allocated_doctor") == temp_user:
            if not dict_name.get(p_id). has_key('medicines'):
                medicine['medicine_name'] = raw_input("Enter Medicine Name:\n")
                medicine['time'] = raw_input("Enter Medicine Time \'Morning-Afternoon-Night\':\n")

                dict_name[p_id]['medicines'] = medicine
                dict_name.update(dict_name)
                print dict_name
                self.back_up_data(dict_name, file_name, corresponding_date)

    # This Function used for getting details of patient for Doctor
    def get_patient_details(self, dict_name, file_path, corresponding_date):

        file_path = file_path + "\\" + corresponding_date + ".txt"
        if path.exists(file_path):
            file_pointer = open(file_path, 'r')
            data = file_pointer.read()
            patient_backup = eval(data)
            # print file_pointer
        else:
            patient_backup = {}
        temp_user = self.user_name
        counter = 0
        dict_name.update(patient_backup)
        for p_id, p_info in dict_name.items():
            # print "\nPatient ID:", p_id

            if dict_name.get(p_id).get("allocated_doctor") == temp_user:
                if not dict_name.get(p_id). has_key('medicines'):
                    print "\nPatient ID:", p_id
                    for key in p_info:
                        print key + ':', p_info[key]
                else:
                    counter = p_id
        return counter

    # Take File backup for patient Function
    def file_backup(self, patient_details, file_path, registration_date):
        # This Function is used for Take New Appointment for OPD
        data = ''
        file_path = file_path + "\\" + registration_date + ".txt"
        if path.exists(file_path):
            file_pointer = open(file_path, 'r')
            data = file_pointer.read()
            patient_backup = eval(data)
            id_for_patient = len(patient_backup)
        else:
            patient_backup = {}
            id_for_patient = 0
        patient_details.update(patient_backup)
        return id_for_patient

    # Generate ID for Patient Function
    def generate_id(self, patient_details, file_path, registration_date):
        # This Function is used for the Generating Patient ID for OPD

        dir_name = file_path + "\\" + registration_date + ".txt"
        if path.exists(dir_name):
            temp_id = self.file_backup(patient_details, file_path, registration_date)
        else:
            temp_id = 0

        if temp_id < 0:
            temp_id = 0
        patient_temp_id = int(temp_id) + 1
        return patient_temp_id

    # After the appointment back up data Function
    def back_up_data(self, patient_details, path_of_file, registration_date):
        # This Function is used for back up the data
        dir_name = path_of_file

        def check_directory(directory_name):
            # Create target Directory if don't exist
            if not path.exists(directory_name):
                mkdir(directory_name)
                # print("Directory ", directory_name, " Created ")
                return directory_name
            else:
                # print("Directory ", directory_name, " already exists")
                return False

        check_directory(dir_name)
        file_path = dir_name + "\\" + registration_date + ".txt"

        if path.isfile(file_path):
            file_pointer = open(file_path, 'w')
        else:
            file_pointer = open(file_path, 'w')

        patient_data = str(patient_details)
        file_pointer.write(patient_data)

    # Common Function Area End

    # Take Appointment Function
    def take_appointment(self):
        # This Function is used for Take Appointment for OPD

        patient_details = {}
        take_appointment_choice = 0
        while take_appointment_choice != 4:
            # The Appointment Menu Enter Choice List
            take_appointment_choice = int(
                raw_input("\nOPD Menu Enter Choice\n1.New Appointment 2. Get all Patient "
                          "3. Go back to Main menu\n"))
            # Checking which choice is made upon that function will called further
            if take_appointment_choice == 1:
                self.new_appointment(patient_details)
            elif take_appointment_choice == 2:
                today_date = str(date.today())
                temp = self.file_backup(patient_details, "opd_patient_details", today_date)
                counter = self.get_details(patient_details, "opd_patient_details", today_date)
                if counter == len(patient_details):
                    print "No Details Available"
            elif take_appointment_choice == 3:
                break
            else:
                print "Please provide valid choice"

    # Take New Appointment Function
    def new_appointment(self, patient_details):
        # This Function is used for Take New Appointment for OPD (UNDER take_appointment FUNCTION)
        # 'name': 'name', 'treatment': 'sac', 'age': '22', 'last_visited_date': 'date', 'doctor_name': 'name'
        details = {}

        temp_patient_details = {}
        patient_name = 'name'
        patient_treatment = 'treatment'
        patient_age = 'age'
        doctor_allocated = 'allocated_doctor'
        patient_id_last_visit_date = 'date'
        details[patient_name] = raw_input("Enter Patient Name\n")
        details[patient_treatment] = raw_input("Enter Treatment of Patient\n")
        details[patient_age] = float(raw_input("Enter Age\n"))
        opd_date = str(date.today())  # date.today() for current date
        details[patient_id_last_visit_date] = opd_date
        patient_id = self.generate_id(patient_details, "opd_patient_details", opd_date)
        details[doctor_allocated] = raw_input("Enter Doctor allocated to patient for OPD\n")
        temp_patient_details[patient_id] = details
        patient_details.update(temp_patient_details)
        self.back_up_data(patient_details, "opd_patient_details", opd_date)
        opd_register = " Patient Appointment Successfully Registered "
        text_opd_register = opd_register.center(50, '-')
        print text_opd_register
        return patient_details

    # Take OT Registration Function
    def take_ot_registration(self):
        # This Function is used for Take Appointment for OPD

        patient_details_of_ot = {}

        take_ot_appointment_choice = 0
        while take_ot_appointment_choice != 3:
            # The Appointment Menu Enter Choice List
            take_ot_appointment_choice = int(
                raw_input("\nOT Menu Enter Choice\n1.New OT Registration 2. Get all Patient "
                          "3. Go back to Main menu\n"))
            # Checking which choice is made upon that function will called further
            if take_ot_appointment_choice == 1:
                self.new_ot_registration(patient_details_of_ot)
            elif take_ot_appointment_choice == 2:
                ot_date = raw_input("Enter date in format \'YYYY-MM-DD\' \n")
                temp = self.file_backup(patient_details_of_ot, "ot_patient_details", ot_date)
                self.get_details(patient_details_of_ot, "patient_details_of_ot", ot_date)
            elif take_ot_appointment_choice == 3:
                break
            else:
                print "Please provide valid choice"

    # Take new OT registration Function
    def new_ot_registration(self, patient_details_of_ot):
        # This Function is used for Take New Appointment for OPD (UNDER take_appointment FUNCTION)
        details_ot = {}

        temp_patient_details = {}
        patient_name = 'name'
        patient_treatment = 'treatment'
        patient_age = 'age'
        doctor_allocated = 'allocated_doctor'
        patient_operation_date = 'date'
        details_ot[patient_name] = raw_input("Enter Patient Name\n")
        details_ot[patient_treatment] = raw_input("Enter Treatment of Patient\n")
        details_ot[patient_age] = float(raw_input("Enter Age\n"))
        # date.today() for current date
        ot_date = raw_input("Enter the Date in format \'YYYY-MM-DD\' \n")
        details_ot[patient_operation_date] = ot_date
        # function call for patient id
        patient_id = self.generate_id(patient_details_of_ot, "ot_patient_details", ot_date)
        details_ot[doctor_allocated] = raw_input("Enter Doctor allocated to patient for OT\n")
        temp_patient_details[patient_id] = details_ot
        patient_details_of_ot.update(temp_patient_details)
        self.back_up_data(patient_details_of_ot, "ot_patient_details", ot_date)
        ot_register = " Patient for OT Successfully Registered "
        text_ot_register = ot_register.center(50, '-')
        print text_ot_register
        return patient_details_of_ot

    # Function for Emergency Case
    def emergency_case(self):
        # This Function is used for Take Appointment for OPD

        emergency_case_patient_details = {}

        emergency_case_choice = 0
        while emergency_case_choice != 3:
            # The Appointment Menu Enter Choice List
            emergency_case_choice = int(
                raw_input("\nEmergency Case Menu Enter Choice\n1.New Emergency Case 2. Get All emergency Cases "
                          "3. Go back to Main menu\n"))
            # Checking which choice is made upon that function will called further
            if emergency_case_choice == 1:
                self.new_emergency_case(emergency_case_patient_details)
            elif emergency_case_choice == 2:
                today_date = str(date.today())
                temp = self.file_backup(emergency_case_patient_details, "emergency_case_patient_details", today_date)
                self.get_details(emergency_case_patient_details, "emergency_case_patient_details", today_date)
            elif emergency_case_choice == 3:
                break
            else:
                print "Please provide valid choice"

    def new_emergency_case(self, emergency_case_patient_details):
        # This Function is used for Take New Appointment for OPD (UNDER take_appointment FUNCTION)
        # 'name': 'name', 'treatment': 'sac', 'age': '22', 'last_visited_date': 'date', 'doctor_name': 'name'
        details = {}

        temp_patient_details = {}
        patient_name = 'name'
        patient_treatment = 'treatment'
        patient_age = 'age'
        doctor_allocated = 'allocated_doctor'
        patient_visit_date = 'date'
        details[patient_name] = raw_input("Enter Patient Name\n")
        details[patient_treatment] = raw_input("Enter Treatment of Patient\n")
        details[patient_age] = float(raw_input("Enter Age\n"))
        emergency_case_date = str(date.today())  # date.today() for current date
        details[patient_visit_date] = emergency_case_date
        # function call for patient id
        patient_id = self.generate_id(emergency_case_patient_details, "emergency_case_patient_details",
                                      emergency_case_date)

        details[doctor_allocated] = raw_input("Enter Doctor allocated to patient for OPD\n")
        temp_patient_details[patient_id] = details
        emergency_case_patient_details.update(temp_patient_details)
        self.back_up_data(emergency_case_patient_details, "emergency_case_patient_details", emergency_case_date)
        opd_register = " Emergency Case Patient Successfully Registered "
        text_opd_register = opd_register.center(50, '-')
        print text_opd_register
        return emergency_case_patient_details


# Main i.e. DRIVER CODE
choice = 1
user_of_system = {}
while choice == 1:
    login_choice = int(raw_input("Enter Choice:\n1. Login 2. Register\n"))

    if login_choice == 1:
        login = " Login Here "
        text_login_center = login.center(50, '-')
        print text_login_center
        user = raw_input("Enter User Name:\n")
        psw = raw_input("Enter password:\n")
        Object = Hospital(user, psw)
        Object.login()
        choice = int(raw_input("\n0. You want to exit...? 1. Continue...!\n"))
    elif login_choice == 2:
        register = " Register Here "
        text_register_center = register.center(50, '-')
        print text_register_center
        user = raw_input("Enter User Name:\n")
        psw = raw_input("Enter password:\n")
        Object = Hospital(user, psw)
        Object.registration()
        login_choice = 1
        # choice = int(raw_input("\n0. You want to exit...? 1. Continue...!\n"))
    else:
        print "Enter valid Choice...!"
        choice = int(raw_input("\n0. You want to exit...? 1. Continue...!\n"))
        Object.clear()
