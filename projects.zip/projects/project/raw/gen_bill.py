billing_details = temp_billing = details = {}
        billing_id = self.generate_id(billing_details, "billing_details", corresponding_date)

        patient_backup = self.get_hospitalized_patient(dict_name, file_name, corresponding_date)
        dict_name.update(patient_backup)
        print dict_name
        billing_date = 'billing_date'
        service_details = 'service_details'
        price = 'price'
        p_id = int(raw_input("Enter Patient Id:\n"))
        if dict_name.get(p_id).has_key('medicines'):
            for k_id, p_info in dict_name.items():
                # print "\nPatient ID:", p_id
                # print "\nPatient ID:", p_id
                for key in p_info:
                    # print key + ':', p_info[key]
                    details[key] = p_info[key]
            print details
            billing_choice = 1
            while billing_choice == 1:
                billing_date_of_patient = raw_input("Enter the Date of Bill in \'YYYY-MM-DD\' Format:\n")
                billing_details[billing_date] = billing_date_of_patient
                billing_details[service_details] = raw_input("Enter the service Details:\n")
                billing_details[price] = float(raw_input("Enter the Price:\n"))
                billing_choice = int(raw_input("0. Do you want generate bill...? "
                                                   "1. Continue Adding Billing Details"))
                if billing_choice == 0:
                    break

            # billing_details['billing_contents'] = billing
            temp_billing[billing_id] = billing_details
            # temp_billing.update(temp_billing)
            print "generated bill", temp_billing
            self.back_up_data(temp_billing, "patient_billing_details", corresponding_date)
            bill_generation = " Patient Bill is Successfully Generated"
            text_bill_generation = bill_generation.center(50, '-')
            print text_bill_generation
            print billing_details
            # self.print_billing(billing_details, p_id)