# temp = self.file_backup(user_of_system, "user_details", "users_of_system")
        if register_choice == 1:
            temp_user_details[user_name] = user_name_value
            temp_user_details[user_role] = 'Receptionist'
        elif register_choice == 2:
            temp_user_details[user_name] = user_name_value
            temp_user_details[user_role] = 'Doctor'
        elif register_choice == 3:
            temp_user_details[user_name] = user_name_value
            temp_user_details[user_role] = 'Billing'
        else:
            print "Provide valid Choice\n"
        temp_user_details[user_password] = self.password
        # date.today() for current date
        # function call for user id
        user_id = self.generate_id(self.users_of_system, "user_details", "users_of_system")
        data[user_id] = temp_user_details
        print data
        temp_data = self.users_of_system
        temp_data.update(data)
        print temp_data
        self.back_up_data(self.users_of_system, "user_details", "users_of_system")
        ot_register = " User Successfully Registered "
        text_ot_register = ot_register.center(50, '-')
        print text_ot_register
        return self.users_of_system