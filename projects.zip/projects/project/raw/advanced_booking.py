    def advanced_booking(self, advanced_booking):
        """This Function is used for Advanced Booking of Appointment
         for OPD (UNDER take_appointment FUNCTION)"""

        advance_booking_id = self.generate_id_for_advanced_booking(advanced_booking)
        # function call for booking id
        details = {}

        temp_patient_details = {}
        patient_name = 'name'
        patient_treatment = 'treatment'
        patient_age = 'age'
        doctor_allocated = 'allocated_doctor'
        booking_date = 'last_visit_date'
        details[patient_name] = raw_input("Enter Patient Name\n")
        details[patient_treatment] = raw_input("Enter Treatment of Patient\n")
        details[patient_age] = float(raw_input("Enter Age\n"))
        details[booking_date] = str(date.today())  # date.today() for current date
        temp_patient_details[advance_booking_id] = details
        advanced_booking.update(temp_patient_details)
        self.back_up_data(advanced_booking, "advanced_booking")
        return advanced_booking

    def generate_id_for_advanced_booking(self, advanced_booking):
        # This Function is used for the Generating Patient ID
        dir_name = "advanced_booking\\" + str(date.today()) + ".txt"
        if path.exists(dir_name):
            temp_id = self.file_backup_for_advanced_booking(advanced_booking)
        else:
            temp_id = 0

        if temp_id < 0:
            temp_id = 0
        patient_temp_id = int(temp_id) + 1
        return patient_temp_id

    def file_backup_for_advanced_booking(self, advanced_booking):
        data = ''
        file_path = "advanced_booking\\" + str(date.today()) + ".txt"
        file_pointer = open(file_path, 'r')
        data = file_pointer.read()
        patient_backup = eval(data)
        id_for_advanced_booking = len(patient_backup)
        advanced_booking.update(patient_backup)
        return id_for_advanced_booking
