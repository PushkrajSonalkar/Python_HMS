# Frozen sets
# Python program to demonstrate
# working of a FrozenSet

# Creating a Set
String = ('A', 'R', 'N', 'A', 'V')

f_set1 = frozenset(String)
print "Frozen Set: ", f_set1

# To print Empty Frozen Set
# No parameter is passed
print "\nEmpty Frozen Set: ", frozenset()
