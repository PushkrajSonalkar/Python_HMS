# Accessing Elements of Lists

table_of_2 = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
i = 0
while i < 10:
    print "table_of_2[%d] is %d " % (i, table_of_2[i])
    i += 1